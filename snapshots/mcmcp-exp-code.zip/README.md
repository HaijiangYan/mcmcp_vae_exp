# Markov Chain Monte Carlo with People&Variational Auto-Encoder

Markov Chain Monte Carlo with People&VAE (MCMCP-VAE) is a method for uncovering  mental representations that exploits an equivalence between a model of
human choice behavior and an element of an MCMC algorithm. 